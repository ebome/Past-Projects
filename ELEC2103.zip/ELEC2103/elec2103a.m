%% ELEC2103 Assignment 2016
% Analysis of the trend of electricity use in one household 

%% Student details
NAME =  'Yang Gao';
SID =   '450614082';
DATE =  '05/10/2016';

%% Abstract
% In order to understand the tendency of electricity consumption in one household (Customer ID 10014678) through using of appliances, we analyse the daily network plug readings in a specific month. 
% After predicting the daily average consumption and justifying the prediction, we will use another advanced model to assess the prediction.
% Moreover, visualization of the collection of energy supply is performed in a simple GUI. 

%% 1.1 Analysis of readings in Sep.
% Daily energy consumptions of six appliances (TV/washing machine/dish washer/ air conditioner/microwave/kettle) in 2013 September (30 days) are crated in a mat file. We draw total 180 readings in scatter plot with histograms on x (day) and y (energy consumption) axes, we can also get six kernel density plots to visualize the relationship, grouped by appliances.
% 
% The figure introduces two histograms. The histogram located horizontally represents the numbers of appliances used every day. The one located vertically represents the appeared times of appliances in each energy interval, which are the kernel density plots.

load ('consumption in sep2013','-mat'); 
x = DAY(:,1);
y = ENERGY_USED(:,1);
figure
scatterhist(x,y,'group',PLUG_NAME,'marker','+od'); 
xlabel('Day');
ylabel('Energy used (kWh)');
title('figure 1 scatterplot and kernel density distribution of appliances');

%% 1.2 Assessment of statistical errors
% To prevent non-sampling error, we assume that watt-hour meter in the household is accurate. 
%
% The sampling errors appear in the raw data, which influences both the scatter plot and the kernel density plots. 
% The ideal sampling of appliance consumptions in one day should start from 0:00 and end at 23:59. However, in the 
% real sampling, some appliances are recorded from noon to afternoon in certain days. This potentially reduce the 
% exact energy consumption values. In addition, some appliances are not recorded in certain days, we treat the energy
% consumption of that appliance as 0 in those days. But in reality, those data has been collected from a part rather than the whole of the day.

%% 1.3 Prediction of energy used in Oct.
% In general, the selected household will follow a similar habit in each month.
%
% We can find the daily average consumption of each appliance in Sep. and generate boxplots. The daily consumption of TV, kettle, air conditioner, dishwasher, 
% washing machine, and microwave are 0.5296, 0.2366, 0.0563, 0.3114, 0.2129, and 0.1115kWh respectively. The boxplots in following figure show the distributions
% of consuming amount. The smaller the length of boxplot, the more pooled of the daily consuming amount of that appliance. 
%
% From the number calculated and the graph plotted, we predict that the average energy used in October would be around 1.5kWh/day.

G = PLUG_NAME(:,1); % G is the group of different appliances
figure
A = boxplot(y,G,'Orientation','horizontal'); % box plots for appliances
title('figure 2.1  boxplot of energy consumptions of appliances')
daily_avg = sum(y)/30;
daily_avg_TV = mean(TV(2:31,1));
daily_avg_kettle = mean(Kettle(2:31,1));
daily_avg_aircon = mean(AirCon(2:31,1));
daily_avg_dishwasher = mean(Dishwasher(2:31,1));
daily_avg_washmachine = mean(WashingMachine(2:31,1));
daily_avg_microwave = mean(Microwave(2:31,1));


%% 1.4 Reliability of prediction
% In 1.3, except boxplot of air conditioner, the rest of boxplots skew to right. This means that the median is larger than the mean in each dataset. In other words, the daily average consumptions in 1.3 are not the most frequent consumptions. In my prediction, I suppose that the difference between each group is not significant so that the boxplot shown in figure 2.1 may not be the ideal distribution of consumptions in each month. In this case, we perform one-way ANOVA method to check if there is significant difference between each dataset. The test statistic in ANOVA is the ratio of the between and within variation in several groups, which is a special case of multiple regression.
% 
% The ANOVA table shows the between-groups variation (Columns) and within-groups variation (Error). SS is the sum of squares, and df is the degrees of freedom. The total degrees of freedom is total number of observations minus one. The between-groups degrees of freedom is number of groups minus one. The within-groups degrees of freedom is total degrees of freedom minus the between groups degrees of freedom. MS is the mean squared error, which is SS/df for each source of variation. The F-statistic is the ratio of the mean squared errors. The p-value is the probability that the test statistic can take a value greater than or equal to the value of the test statistic, i.e., p(F > 11.19)=2.28567e-09=0.0003. 
%
% The boxplots here is different from figure 2.1. It is the observations in D, the matrix collecting all consumption values. Two medians are significantly different at the 5% significance level if their intervals do not overlap.
%
% The plot shows one box for each column of D. On each box, the central mark is the median and the edges of the box are the 25th and 75th percentiles (1st and 3rd quantiles). The whiskers extend to the most extreme data points that are not considered outliers. The outliers are plotted individually. The interval endpoints are the extremes of the notches. The extremes correspond to q2 �C 1.57(q3 �C q1)/sqrt(n) and q2 + 1.57(q3 �C q1)/sqrt(n), where q2 is the median (50th percentile), q1 and q3 are the 25th and 75th percentiles, respectively.
%
% The table and results show below indicates that the differences between dataset are significant as p<0.01.Thus my prediction that the average consumption is 1.5kWh/day may not be correct. However, there are still so many underlying factors which influence the consumptions in this household. (eg.friend comes to visit and thus increasing some consumption in Sep only, family go outside for several days ). More complicated models should be built to analyse the data.

group = [G(1:6,1)]; % we figure out the types of appliances
D = horzcat(Microwave(:,1),Dishwasher(:,1),TV(:,1),WashingMachine(:,1),Kettle(:,1),AirCon(:,1));  
% horizontal concatenation of matrices of six appliances
% the length of group and D are same so that we can perform one-way ANOVA

p = anova1(D,group);
title('figure 2.2 boxplot to visualize group location parameters ')

%% 2.1 ARMA model
% In 1.4, the prediction of accurate daily energy consumption maybe wrong as it assumes that there is not significant difference between 
% each group (energy consumption for six appliances). We choose autoregressive-moving-average model to optimize the prediction. The ARMA model 
% is a tool for understanding and predicting future values in a time series of data Xt. The model consists of two parts, an autoregressive (AR) part
% and a moving average (MA) part. The AR part involves regressing the variable on its own lagged (i.e., past) values. The MA part involves modelling 
% the error term as a linear combination of error terms occurring contemporaneously and at various times in the past. The entire structure of the ARMA 
% models depends on prior values and independent random events over time, not on any explanatory or causative factors.
%
% In addition, the ARIMA model is a generalization of ARMA model, which introduced integrated (I) part. This part involves non-stationary series, whose
% statistical properties such as mean, variance, autocorrelation, etc. are not constant over time. However, the household is supposed to have same habit 
% each month. In this case, ARMA is better than ARIMA. The habit also tells us that the daily consumption is not independent; in other words, daily consumption
% amount may regress to a fixed value.
%
% We will first get the time series data for daily energy consumption. Then we check the autocorrelation and heteroscedasticity to test if ARMA model is suitable. 
% Here, we do not use raw values. Instead, we define a return of raw data, which is achieved by command ��price2ret��. Benefit of using returns, versus raw data, is 
% normalization: measuring all variables in a comparable metric, thus enabling evaluation of analytic relationships amongst variables despite originating from time 
% series of unequal values. 
%
% After constructing the model, we will estimate the exact parameters to optimize it. Then we use the model to predict the daily energy consumption in the household.
%
a = Microwave(2:31,:); % ignore the first element in row of Microwave, since it's a string
b = TV(2:31,:); 
c = WashingMachine(2:31,:);
d = Dishwasher(2:31,:);
e = Kettle(2:31,:);
f = AirCon(2:31,:);

%create a matrix to show daily energy consumption(sum of six appliances)
for i=1:30 % 30 days in Sep
    row_matrix= horzcat(a(i,:),b(i,:),c(i,:),d(i,:),e(i,:),f(i,:));
    s(i) = sum(row_matrix,2); % sum the row of matrix
end
s1 = cumsum(s); % s1 gives accumulative values for s
% Now we get a matrix called s1,which contains 30 days' consumption.
% We have prepared a time series data,which is a row matrix
%
ret = price2ret(s1); % command "price2ret" convert s1 to return
figure % we want to display all the figures rather than show only the last figure 
plot(ret);
xlim([0,length(ret)]);
title('figure 3.1 Autoregression of daily average energy consumption'); 
%
% Figure3.1 shows autoregression, but we want to check if there is significant autocorrelation in the data,so we perform Ljung-Box Q-test
% The null hypothesis H0 is that all autocorrelations are 0 up to lagged values.  
% If h=1, reject H0. p gives the probability of rejecting H0
[h,p] = lbqtest(ret,'Lags',28); % lags cannot exceed the length of the data minus one. i.e.lags are smaller than 29
%
% We check if the error terms occur contemporaneously and at various times in the past 
% To do this, we apply Engle test for residual heteroscedasticity
% The null hypothesis is that a series of residuals (rt) exhibits no conditional heteroscedasticity (ARCH effects)
% If h=1,reject null hypothesis. p gives the probability of rejecting H0
[h,p] = archtest(ret-mean(ret),'lags',27); % lags cannot exceed the length of the data minus one. i.e.lags are smaller than 28
%
% Start to fit ARMA model
% We don't know the variance of population in model so regard it as gaussian-distribution
% The following line shows the ARMA model I build 
model = arima('ARLags',14,'MALags',14,'Constant',0); % To increase degree of freedom,just decrease amount of lags
%
% We start to optimize the model
r = (ret)'; % To help command "estimate" work, transpose row matrix ret into column matrix r
EstMdl = estimate(model,r); % estimate parameters in my ARMA model
[E0,V0] = infer(EstMdl,r); % E0 is presample innovations, V0 is presample conditional variances
[res,V,logL] = infer(EstMdl,r); % res is inferred residuals,V is infeered conditional variances,logL is Loglikelihood objective function values
% 
% We now try to stimulate the data in future 
% Y is numObs-by-NumPaths matrix of simulated response data,E is numObs-by-NumPaths matrix of simulated mean zero innovations
% V is numObs-by-NumPaths matrix of simulated conditional variances of the innovations in E
[Y,E,V] = simulate(EstMdl,100,'numPaths',90,'Y0',r,'E0',E0,'V0',V); % numObs=100,NumPaths=90;100 means 100 days in the future, 90 means 90 times simulations
figure
plot([1:100],Y);
title('figure 3.2 Simulated returns');
%
% Prediction of daily energy used using estimated model
% Y is minimum mean square error forecasts of response data, YMSE is mean square errors forecasts of conditional mean
% V is minimum mean square error forecasts of conditional variances of future model innovations
[Y,YMSE,V] = forecast(EstMdl,100,'Y0',r,'E0',E0,'V0',V); % predict 100 days
figure
plot([1:100],Y,[1:100],YMSE,[1:100],V);
title('figure 3.3 Forecasted returns and forcasted conditional variances');
% We can see three lines in 3.3, although the forecasted returns YMSE and forcasted conditional variances V are too close to see
% 
%The ployline in 3.3 indicates the volatility of mean square error forecasts of response data


% In summary,the figures shown in this section tell us that useing the ARMA model to
% predict future value is acceptable. The s1 matrix fits a linear
% regression line: consumption=day*1.6-1.8. In this case, we predict that
% the daily average energy consumption in future is 1.6kWh


%% 2.2 Visualization of data
% The code of GUI is attached in separate m-file called ��GUI��. 
% However, I didn��t figure out how to make the opening and callback functions run properly. 

%% University of Sydney statement concerning plagiarism
% I certify that:
%
% (1) I have read and understood the University of Sydney Academic Dishonesty and Plagiarism Policy  (found by following the  Academic Honesty link on the Unit web page).';
%
% (2) I understand that failure to comply with the Student Plagiarism: Coursework Policy and Procedure can lead to the University commencing proceedings against me for potential student misconduct under Chapter 8 of the University of Sydney By-Law 1999 (as amended).';
%
% (3) This Work is substantially my own, and to the extent that any part of this Work is not my own I have indicated that it is not my own by Acknowledging the Source of that part or those parts of the Work as described in the assignment instructions.';
%
% Name: Yang Gao
%
% SID: 450614082
%
% Date: 05/10/2016
