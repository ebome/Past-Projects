import java.io.*;// the java.io.* will include all the methods in "util" class
import java.util.*;// the java.util.* will include all the methods in "util" class
/**
 * Maze Game
 * INFO1103 Assignment 2
 * 2017 Semester 1
 *
 * @author Yang Gao
 * @date April, 2017
 */

/**
 * Maze Game Class.
 *
 * You will have a maze board and a player moving around the board.
 * The player can step left, right, up or down.
 * However, you need to complete the maze within a given number of steps.
 *
 * As in any maze, there are walls that you cannot move through. If you try to
 * move through a wall, you lose a life. You have a limited number of lives.
 * There is also gold on the board that you can collect if you move ontop of it.
 *
 * Please implement the methods provided, as some of the marks are allocated to
 * testing these methods directly.
 *
 *
 */
 public class MazeGame {
     /*variables that you need throughout the class up here.
      * You MUST INITIALISE ALL of these class variables in your initialiseGame
      * method.
      */

     // You would initialise these variables in initialiseGame method.
     // Have the following lines in the initialiseGame method.
     static int life; //the entire class need to know this information [static variable]
     static int step;
     static int gold;

     static int y; // y is the number of rows; NOTE that it should be counted from 2nd line in maze.txt but not 1st line
     static int x; // x is the total number of columns

     static int xCoordination;
     static int yCoordination;
     static int xEnd;
     static int yEnd;
     static String[] board;
     static char[][] maze;
 //Start to define methods, take care about "return type"
     /**
      * Initialises the game from the given configuration file.
      * This includes the number of lives, the number of steps, the starting gold
      * and the board.
      *
      * note: Please also initialise all of your class variables.
      *
      * @ args configFileName: The name of the game configuration file to read from.
      * @ throws IOException : If there was an error reading in the game.
      *         For example, if the input file could not be found.

      *         We don't need to throw it out.
      *throws: tell us "all the possible exceptions" this method will throw
      *throw: a secific type of exception
      */
     /*we should put the try-catch in main method where you call this method, but
     not inside this method
      */
  public static void initialiseGame(String configFileName) throws IOException {
      File inputFile = new File(configFileName);// define what is the file name
      Scanner fileScanner = new Scanner(inputFile);// use scanner to read

      life = fileScanner.nextInt();//"nextInt()" only gives one integer each time
      step = fileScanner.nextInt();// we need initialise all these values to manipulate later
      gold = fileScanner.nextInt();//life/step/gold mean that player will see them each time, so they three are REMAINIG values
      y = fileScanner.nextInt(); //we can't count 1st line in maze.txt, this y tells the horizontal coordination
      /*From Google: The problem occurs as you hit the enter key, which is a newline \n character. nextInt() consumes only the integer,
      * but it skips the newline \n . To get around this problem, you may need to add an additional input.nextLine() after
      * you read the int , which can consume the \n
      */
      fileScanner.nextLine();//we ask the scanner skip current line, without this code it will continue to read from 1st line

      board = new String[y];// we need to store the board later, so create an array to find column number
      for(int index=0;index<y;index++){
          board[index] = fileScanner.nextLine(); //store each input line into a String array
      }
      x = board[0].length();

      maze = new char [y][x]; // to help manipulate later, I initialise this again
      int rowindex=0;
      while(rowindex<y){ // n is actually rowIndex
         for(int colndex=0;colndex < x;colndex++){
           if (colndex<(board[rowindex].length())){
                 maze[rowindex][colndex]=board[rowindex].charAt(colndex);// write the board into maze 2d array
           }
         }//inner for loop
         rowindex++;
      }// for loop

  //get coordination of player and destination
      for (int i =0;i<y;i++){
        for (int j = 0; j<x;j++){
           if(board[i].charAt(j)=='&'){
                xCoordination=j;
                yCoordination=i;
           }// if-statement bracket
           if(board[i].charAt(j)=='@'){
                 xEnd=j;
                 yEnd=i;
            }

          }
        }
    }//initialiseGame method

    /**
     * Save the current board to the given file name.
     * Note: save it in the same format as you read it in.
     * That is:
     *
     * <number of lives> <number of steps> <amount of gold> <number of rows on the board>
     * <BOARD>
     *
     * @args toFileName : The name of the file to save the game configuration to.
     * @ throws IOException : If there was an error writing the game to the file.
     */
    public static void saveGame(String toFileName) throws IOException {
         File outputFile = new File ( toFileName );
         PrintWriter out = new PrintWriter(outputFile);  //line that makes a new PrintWriter

         out.print(life+" ");//line that writes lives,gold etc to file
         out.print(step+" ");
         out.print(gold+" ");
         out.print(y+"\n");// writing back means we need to follow the same configuration as original text file

         //write current board back to the file
         int rowNum = 0;
         while (rowNum<y){
             for (int colNum = 0;colNum<x;colNum++){
                out.print(maze[rowNum][colNum]);
             }
           out.print("\n");//This way is same in my code for Assignment"Reverse the string"
           rowNum++;
         }

         out.close();//close the printwriter
         System.out.print("Successfully saved the current game configuration to '"+toFileName+"'.'");
    }//saveGame method

        /**
         * Gets the current x position of the player.
         * go through each element of the board array to find the character that matches '&'
         * @return The players current x position.
         */
      public static int getCurrentXPosition() {
        //board = new String[rows];//Don't use this line
        /*It is replacing the current board with an array of Strings.
         The default value for a string is null, so this array ends up with all the values being null.
         When call .length() on this null value, it causes a NullPointerException.
        */
            return xCoordination;
      }// getCurrentXPosition method

      /**
       * Gets the current y position of the player.
       *
       * @ return The players current y position.
       */
      public static int getCurrentYPosition() {
         return yCoordination;
      }// getCurrentYPosition method

      /**
       * Gets the number of lives the player currently has.
       *
       * @return The number of lives the player currently has.
       */
      public static int numberOfLives() {
          return life;
      }

      /**
       * Gets the number of remaining steps that the player can use.
       *
       * @return The number of steps remaining in the game.
       */
      public static int numberOfStepsRemaining() {
          return step;
      }

      /**
       * Gets the amount of gold that the player has collected so far.
       *
       * @return The amount of gold the player has collected so far.
       */
      public static int amountOfGold() {
          return gold;
      }
      /**
       * Checks to see if the player has completed the maze.
       * The player has completed the maze if they have reached the destination.
       *
       * @return True if the player has completed the maze.
       */
   public static boolean isMazeCompleted() {

      //If & is in destination when it didn't use up steps,it wins
      if(step<0){
        return false;
      } else if (maze[yEnd][xEnd]!='&'){
        return false;
      } else if(step>=0 && maze[yEnd][xEnd]=='&'){
        return true;
      }else {
        return false;
      }

 }// isMazeCompleted method

     /**
      * Checks to see if it is the end of the game.
      * It is the end of the game if one of the following conditions is true:
      *  - There are no remaining steps.
      *  - The player has no lives.
      *  - The player has completed the maze.
      *
      * @ return True if any one of the conditions that end the game is true.
      */
     public static boolean isGameEnd() {
       if(step<=0){
         return true;
       }else if(life<=0){
         return true;
       }else if(isMazeCompleted()){
         return true;
       } else {
         return false;
       }
     }// isGameEnd method

     /*
      * Checks if the coordinates (x, y) are valid.
      * That is, if they are on the board.
      *
      * @args x The x coordinate.
      * @args y The y coordinate.
      * @ return True if the given coordinates are valid (on the board),
      *         otherwise, false (the coordinates are out or range).
      */
      /*From ED:The method here just simply checked (int x, int y) is valid or not .
      When you calling this method in canMoveTo(), if the coordinate is not valid,
      just return false. The isValidCoordinates(int x , int y) just helps us to simply
       the method canMoveTo(), which has more than 1 situation to return false.
       Calling canMoveTo() in the method moveTo(), if it is false, then change nothing
       and steps -=1. Even if the player can only give the following commands: up, down,
       right or left, when the player is at (0,2) and he wanna go left, it is not valid.
       The first thing you have to do is to get the current coordinate (x,y) and in the
       method performAction to get the goal coordinates and calling the moveTo() method.
       E.g. the original coordinate is (x , y) and the command is left, then, moveTo( x-1, y ).
      */
     public static boolean isValidCoordinates(int a, int b) {
             // to distiguish a b from x y, I change the scaffold
             if(a>=0 && a<x && b>=0 && b<y){
                    return true;
             }else{
                    return false;
             }
     }// isValidCoordinates method

     /**
      * Checks if a move to the given coordinates is valid.
      * A move is invalid if:
      *  - It is move to a coordinate off the board.
      *  - There is a wall at that coordinate.
      *  - The game is ended.
      *
      * @args x The x coordinate to move to.
      * @args y The y coordinate to move to.
      * @return True if the move is valid, otherwise false.
      */
     public static boolean canMoveTo(int a, int b) {

       if(a<0){  //move out of board
         return false;
       } else if(a>=x){ //move out of board
         return false;
       }else if(b<0){  //move out of board
         return false;
       } else if(b>=y){  //move out of board
         return false;
       }else if(isGameEnd()){
         return false;
       }else if(maze[b][a]=='#'){
         return false;
       }else{
         return true;
       }

     }//canMoveTo method

     /**
      * Move the player to the given coordinates on the board.
      * After a successful move, it prints "Moved to (x, y)."
      * where (x, y) were the coordinates given.
      *
      * If there was gold at the position the player moved to,
      * the gold should be collected and the message "Plus n gold."
      * should also be printed, where n is the amount of gold collected.
      *
      * If it is an invalid move, a life is lost.
      * The method prints: "Invalid move. One life lost."
      *
      * @args x The x coordinate to move to.
      * @args y The y coordinate to move to.
      */
     public static void moveTo(int a, int b) {

        if (!canMoveTo(a,b)){
          System.out.println("Invalid move. One life lost.");
          step=step-1;
          life=life-1;
        } else if(canMoveTo(a,b)){

          //Check if there is gold or not, and get the gold
                if ( Character.isDigit(maze[b][a]) ){ // if at the location there is a character(represent gold number)
                      // int goldGet = Character.getNumericValue(maze[b][a]);
                        int goldGet = (char)maze[b][a]-'0';

   /*"Character.isDigit(char ch)"detect digits from a char using Character class
 "Character.getNumericValue(char ch)" returns the int value that the character represents
   See https://docs.oracle.com/javase/8/docs/api/java/lang/Character.html#isDigit-char-
   and https://docs.oracle.com/javase/8/docs/api/java/lang/Character.html#isDigit-char-
   */
                         gold += goldGet;
                         System.out.println("Plus "+goldGet+" gold.");
                 }
 //Even if there is no gold in the location, the player will still stand there
          System.out.println("Moved to ("+ a +", "+ b +").");
          maze[b][a]='&';
          step=step-1;
          xCoordination = a;
          yCoordination = b;
        }

      }//moveTo method

 /**
  * Prints out the help message.
  */
  public static void printHelp() {
          System.out.println("Usage: You can type one of the following commands.");
          System.out.println("help         Print this help message.");
          System.out.println("board        Print the current board.");
          System.out.println("status       Print the current status.");
          System.out.println("left         Move the player 1 square to the left.");
          System.out.println("right        Move the player 1 square to the right.");
          System.out.println("up           Move the player 1 square up.");
          System.out.println("down         Move the player 1 square down.");
          System.out.println("save <file>  Save the current game configuration to the given file.");
  }

/**
 * Prints out the status message.
 */
  public static void printStatus() {
          System.out.println("Number of live(s): "+numberOfLives());
          System.out.println("Number of step(s) remaining: "+numberOfStepsRemaining());
          System.out.println("Amount of gold: "+amountOfGold());
  }

/**
 * Prints out the board.
 */
   public static void printBoard() {
         //This is same as in saveGame() method
        int i =0;
         while ( i<y ){
              for (int j = 0;j<x;j++){
                  System.out.print(maze[i][j]);
              }
         i++;
         System.out.print("\n");
         }
   }//printBoard method

   /**
    * Performs the given action by calling the appropriate helper methods.
    * [For example, calling the printHelp() method if the action is "help".]
    *
    * The valid actions are "help", "board", "status", "left", "right",
    * "up", "down", and "save".
    * [Note: The actions are case insensitive.]
    * If it is not a valid action, an IllegalArgumentException should be thrown.
    *
    * @args action The action we are performing.
    * @ throws IllegalArgumentException: If the action given isn't one of the
    *         allowed actions.
    */
  public static void performAction(String action) throws IllegalArgumentException {
       int x1 = xCoordination;
       int y1 = yCoordination;

       /* type"save" command when play maze game: since we call "saveGame(String toFileName)"
       to save file, it may throw IOException

       From Ed: "String.equalsIgnoreCase(anotherString)"compares this String to another String, ignoring case considerations.
       Two strings are considered equal ignoring case, if they are of the same length,
        and corresponding characters in the two strings are equal ignoring case.
        From Google: The substring() method extracts the characters from a string, between two specified indices, and returns the new sub string.
       */
      if(action.equalsIgnoreCase("help")){
            printHelp();
      }else if(action.equalsIgnoreCase("status")){
            printStatus();
      }else if(action.equalsIgnoreCase("board")){
            printBoard();

      }else if(action.equalsIgnoreCase("up")){
            y1--;
            if(canMoveTo(x1,y1)){
              maze[yCoordination][xCoordination]='.';
              moveTo(x1,y1);
              //change currentPosition to relocated position
            }else{
              moveTo(x1,y1);
            }
      }else if(action.equalsIgnoreCase("left")){
            x1--;
            if(canMoveTo(x1,y1)){
              maze[yCoordination][xCoordination]='.';
              moveTo(x1,y1);
              //change currentPosition to relocated position
            }else{
              moveTo(x1,y1);
            }
      }else if(action.equalsIgnoreCase("down")){
            y1++;//target position.
            if(canMoveTo(x1,y1)){
              maze[yCoordination][xCoordination]='.';
              moveTo(x1,y1);
              //change currentPosition to relocated position
            }else{
              moveTo(x1,y1);
            }
      }else if(action.equalsIgnoreCase("right")){
            x1++;
            if(canMoveTo(x1,y1)){
              maze[yCoordination][xCoordination]='.';
              moveTo(x1,y1);
              //change currentPosition to relocated position
            }else{
              moveTo(x1,y1);
            }
      } else if(action.length()>5 && action.substring(0,4).equalsIgnoreCase("save")){
                  String toFileName = action.substring(5);
                  if(toFileName.length()<=4){
                    throw new IllegalArgumentException();
                  }
                  int offset=toFileName.length()-4;
                  String Suffix = toFileName.substring(offset);
                  if(!Suffix.equalsIgnoreCase(".txt")){ //if the ending is not .txt
                    throw new IllegalArgumentException();
                  }
                  // when saving file fails, throw out the exception
                  try{
                    saveGame(toFileName);
                  }catch (IOException e){
                    System.out.println("Error: Could not save the game configuration to \'" +toFileName+"\'.");
                    return;
                  }
      }else{
            throw new IllegalArgumentException();
      }

  }//performAction methods.

    /**
     * The main method of your program.
     *
     * @args args[0] The game configuration file from which to initialise the
     *       maze game. If it is DEFAULT, load the default configuration.
     */
    public static void main(String[] args) {
        // Run your program (reading in from args etc) from here.

      try{
          if(args.length>1){ // test if input is exactly one file
            throw new IllegalArgumentException("Error: Too many arguments given. Expected 1 argument, found "+args.length+".\n"+"Usage: MazeGame [<game configuration file>|DEFAULT]");
          } else if (args.length<1){
            throw new IllegalArgumentException("Error: Too few arguments given. Expected 1 argument, found 0.\n"+"Usage: MazeGame [<game configuration file>|DEFAULT]");
          }
          initialiseGame(args[0]);
      } catch (IOException e1){ // in initialiseGame method, we have IOException, which means the file may not exist
            System.out.println("Error: Could not load the game configuration from '" +args[0]+"'.");
            return;
      // } catch (IllegalArgumentException e2){
      //       System.out.println(e2.getMessage());
      //       return;
        }

       //After check input file is valid, start to play
        Scanner scan = new Scanner(System.in);
        String command="";// action is a string defined in method: performAction

            while(scan.hasNextLine()||!isGameEnd()){ // as game is not finished
              //player type the wrong command
              try{
                    command = scan.nextLine();
                    performAction(command);
              }catch(IllegalArgumentException e3){
                     System.out.println("Error: could not find command '" + command + "'.");
                     System.out.println("To find the list of valid commands, please type 'help'.");
              }

              //player finished/not finished the game
              if(isMazeCompleted()){
                System.out.println("Congratulations! You completed the maze!\n"+"Your final status is:");
                performAction("status");
                return;
              }else if(!isMazeCompleted() && isGameEnd()){
                  if(step>0 && life<=0){
                     System.out.println("Oh no! You have no lives left.");
                     System.out.println("Better luck next time!");
                  }else if(step<=0 && life>0){
                     System.out.println("Oh no! You have no steps left.");
                     System.out.println("Better luck next time!");
                  }else if(step<=0 && life<=0){
                      System.out.println("Oh no! You have no lives and no steps left.");
                     System.out.println("Better luck next time!");
                  }
                  return;
              }else if(!scan.hasNextLine()){
                  System.out.println("You did not complete the game.");
                  return;
              }

            }//end while


    }

}
/*Reference source: Xiaoxi Hou. We discussed this assignment together, and use some similar syntax to implement the desired functions
* Special thanks to Xiaoxi's help
*/
