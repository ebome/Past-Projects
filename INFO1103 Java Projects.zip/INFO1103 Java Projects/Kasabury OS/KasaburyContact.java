
/**
 * Kasabury Mobile Phone Contact Class.
 *
 * INFO1103 Assignment 3, Semester 1, 2017.
 *
 * KasaburyContact
 *
 * == Contact data ==
 * Each KasaburyContact stores the first name, last name and phone number of a person.
 * These can be queried by calling the appropriate get method. They are updated
 * with new values. The phone number can only be a 6 - 14 digit number.
 * The chat history is also stored.
 *
 *
 * == Chat history ==
 * Each KasaburyContact stores the history of chat messages related to this contact.
 * Suppose there is a conversation between Angus and Beatrice:
 *
 * Angus: Man, I'm so hungry! Can you buy me a burrito?
 * Beatrice: I don't have any money to buy you a burrito.
 * Angus: Please? I haven't eaten anything all day.
 *
 * Each time a message is added the name of the person and the message is
 * combined as above and recorded in the sequence it was received.
 *
 * The messages are stored in the instance variable String array chatHistory. Provided for you.
 * Unfortunately there are only 20 messages maximum to store and no more.
 * When there are more than 20 messages, oldest messages from this array are discarded and
 * only the most recent 20 messages remain.
 *
 * The functions for chat history are
 *   addChatMessage
 *   getLastMessage
 *   getOldestMessage
 *   clearChatHistory()
 *
 * Using the above conversation as an example
 *   addChatMessage("Angus", "Man, I'm so hungry! Can you buy me a burrito?");
 *   addChatMessage("Beatrice", "I don't have any money to buy you a burrito.");
 *   addChatMessage("Angus", "Please? I haven't eaten anything all day.");
 *
 *   getLastMessage() returns "Angus: Please? I haven't eaten anything all day."
 *   getOldestMessage() returns "Angus: Man, I'm so hungry! Can you buy me a burrito?"
 *
 *   clearChatHistory()
 *   getLastMessage() returns null
 *   getOldestMessage() returns null
 *
 *
 * == Copy of contact ==
 * It is necessary to make copy of this object that contains exactly the same data.
 * There are many hackers working in other parts of Kasabury, so we cannot trust them
 * changing the data. A copy will have all the private data and chat history included.
 *
 *
 * Please implement the methods provided, as some of the marking is
 * making sure that these methods work as specified.
 *
 * @ author A INFO1103 tutor.
 * @ date April, 2017
 *
 */
public class KasaburyContact
{
	public static final int MAXIMUM_CHAT_HISTORY = 20;	//MAXIMUM_CHAT_HISTORY will be fixed through whole class

	/* given */
	protected String[] chatHistory;//protected is a version of public restricted only to subclasses

  private String fname;
	private String lname;
	private String pnumber;
	private int messageNum;

/* from ED: every time you construct a new contact, it will have it's own chatHistory attached.
 If you initialise it outside the constructor, your newly constructed contact won't have it's
 own chat history
 */

 //public KasaburyContact() without return type == constructor returns an object
	public KasaburyContact(String fname, String lname, String pnumber) {
		/* given */
		this.chatHistory = new String[MAXIMUM_CHAT_HISTORY];
		this.messageNum = 0;
		this.fname=fname;
		this.lname=lname;
		this.pnumber=pnumber;
	}//KasaburyContact

	public String getFirstName() { //getter
     return this.fname;
	}
	public String getLastName() { //getter
     return this.lname;
	}
	public String getPhoneNumber() { //getter
     return this.pnumber;
	}

	/* if firstName is null the method will do nothing and return
	 */
	public void updateFirstName(String firstName) { //setter
		 if(firstName == null ){
			 return;
		 }
		 this.fname=firstName; //@NOTE the method MUST return something outside if-statement
	}//updateFirstName method

	/* if lastName is null the method will do nothing and return
	 */
	public void updateLastName(String lastName) {
		if(lastName == null ){ // when last name is null
			return;
		}
		this.lname=lastName;
	}//updateLastName method

	/* only allows integer numbers (long type) between 6 and 14 digits
	 * no spaces allowed, or prefixes of + symbols
	 * leading 0 digits are allowed
	 * return true if successfully updated
	 * if number is null, number is set to an empty string and the method returns false
	 */

	 // the phone number is a String with all characters to be numerical, and this String has a length between 6-14.
	public boolean updatePhoneNumber(String number) { //Assume correct inputs unless specified in the assignment specifications
     int a = number.length();

     if(number==null){ // phone number is empty @NOTE do not use "" since it is a collection
			  return false;
		 }
		 if(a<6 || a>14){ //check phone number length is 6-14 digits
			  return false;
		 }
		 // check space or + in phone number
			for(int i=0;i<a;i++){
				  if(number.charAt(i)==' ' ){
					  return false;
				  }
			    if(number.charAt(i)=='+'){
					  return false;
				  }
			}// for loop

		 this.pnumber = number;//if phone numbers are integer numbers (long type)
     return true; // return true if successfully updated
	} // updatePhoneNumber method

	/* add a new message to the chat
	 * The message will take the form
	 * whoSaidIt + ": " + message
	 *
	 * if the history is full, the oldest message is replaced
	 * Hint: keep track of the position of the oldest or newest message!
	 */
	public void addChatMessage(String whoSaidIt, String message) {
		 // put all the chattings into storage
	// 	 for(int i=0;i<MAXIMUM_CHAT_HISTORY;i++){
	// 		   if(this.chatHistory[i]!=null){
  //           this.chatHistory[i+1]=whoSaidIt + ": " + message;
	// 		   }else{
  //           this.chatHistory[i]=whoSaidIt + ": " + message;
	// 		   }
  //    }
	 //
	// 	//if the last storage room is filled, and now we need add one more chatting
  //  String[] deleteOldChat=new String[MAXIMUM_CHAT_HISTORY];
	//  if(this.chatHistory[MAXIMUM_CHAT_HISTORY]!=null){ //if the last storage room is filled
	// 		   for(int j=0;j<MAXIMUM_CHAT_HISTORY-1;j++){ // largest val of j=18
	// 		     	deleteOldChat[j]=this.chatHistory[j+1];
	// 		   }
	// 	        deleteOldChat[MAXIMUM_CHAT_HISTORY]=whoSaidIt + ": " + message;
	//  }

	//use the elments from the array rather than find the null value
	if(this.messageNum+1 > MAXIMUM_CHAT_HISTORY){ //if the last storage room is filled, and now we need add one more chatting
     // delete the first message and add the new one to last storage room
		 for(int i = 0; i < MAXIMUM_CHAT_HISTORY-1; i++){
			  this.chatHistory[i] = this.chatHistory[i+1];
		 }
		    this.chatHistory[MAXIMUM_CHAT_HISTORY-1] = whoSaidIt + ": " + message;
				this.messageNum=this.messageNum;
	}
	this.chatHistory[this.messageNum] = whoSaidIt + ": " + message;
	this.messageNum=this.messageNum+1;
	}// addChatMessage method

	/* after this, both last and oldest message should be referring to index 0
	 * all entries of chatHistory are set to null
	 */
	public void clearChatHistory() {
		for(int i=0;i<MAXIMUM_CHAT_HISTORY;i++){
				 this.chatHistory[i]=null;
				 this.messageNum=0;
		}
	}//clearChatHistory  method

	/* returns the last message this contact sent
	 * if no messages, returns null
	 */
	public String getLastMessage() { //getter
    // if no messages, returns null
		for(int i=0;i<MAXIMUM_CHAT_HISTORY;i++){
			if(i==0){
				if(this.chatHistory[i]==null){
					return null;
				}else if(this.chatHistory[i]!=null){
					continue;
				}
			}
			//as i=0 checks the 1st message, now i=1 checks the rest message
			if(i!=0){
				if(this.chatHistory[i]==null){
					  return this.chatHistory[i-1];
				}
			}
		}//for loop
		return this.chatHistory[19]; // the latest will always be index 19
	}// getLastMessage method

	/* returns the oldest message in the chat history
	 * depending on if there was ever MAXIMUM_CHAT_HISTORY messages
	 * 1) less than MAXIMUM_CHAT_HISTORY, returns the first message
	 * 2) more than MAXIMUM_CHAT_HISTORY, returns the oldest
	 * returns null if no messages exist
	 */
	public String getOldestMessage() {
		// if no messages, returns null
			if(this.chatHistory[0]==null){
				  return null;
			}

			 //if there is messages
				//check if there was ever MAXIMUM_CHAT_HISTORY messages
			// 	if(this.messageNum+1 > MAXIMUM_CHAT_HISTORY){ //more than MAXIMUM_CHAT_HISTORY
			//      // delete the first message and add the new one to last storage room
			// 		 for(int i = 0; i < MAXIMUM_CHAT_HISTORY-1; i++){
			// 			  this.chatHistory[i] = this.chatHistory[i+1];
			// 		 }
			// 	 }else if()
			// 	this.chatHistory[this.messageNum] = whoSaidIt + ": " + message;
			//
			// 	for(int i=0;i<MAXIMUM_CHAT_HISTORY;i++){
  		// 		if((chatHistory[i]!=null)){
			// 			return this.chatHistory[i];
			// 		}
			// 	}// for loop
			// }//else
			return this.chatHistory[0]; // the latest will always be index 0
	}//getOldestMessage method


	/* creates a copy of this contact, the chatMessage should be copied as well
	 * returns a new KasaburyContact object with all data same as the current object
	 */
	public KasaburyContact copy(   )	{
		 KasaburyContact copyOfContact = new KasaburyContact(this.fname,this.lname,this.pnumber);
     copyOfContact.chatHistory=this.chatHistory;
		 copyOfContact.messageNum=this.messageNum;
     return copyOfContact;
	}

	/* -- NOT TESTED --
	 * You can impelement this to help with debugging when failing ed tests
	 * involving chat history. You can print whatever you like
	 * Implementers notes: the format is printf("%d %s\n", index, line);
	 */
	public void printMessagesOldestToNewest() {
    for(int i=0;i<MAXIMUM_CHAT_HISTORY;i++){
			 System.out.println(this.chatHistory[i]);
		}
	}//printMessagesOldestToNewest method

}// Class
