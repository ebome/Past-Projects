/**
 * Kasabury Mobile Phone Class.
 *
 * INFO1103 Assignment 3, Semester 1, 2017.
 *
 * KasaburyMobile
 * In this assignment you will be creating an Kasabury Mobile Phone as part of a simulation.
 * The Mobile phone includes several attributes unique to the phone and has simple functionality.
 * You are to complete 2 classes. KasaburyMobile and KasaburyContact
 *
 * The phone has data
 *  Information about the phone state.
 *    If it is On/Off
 *    Battery level
 *    If it is connected to network.
 *    Signal strength when connected to network
 *  Information about the current owner saved as contact information.
 *    First name
 *    Last name
 *    Phone number
 *  A list of 10 possible contacts.
 *    Each contact stores first name, last name, phone number and chat history up to 20 messages
 *
 * The phone has functionality
 *  Turning on the phone
 *  Charging the phone. Increase battery level
 *  Change battery (set battery level)
 *  Use phone for k units of battery (decreases battery level by k)
 *  Search/add/remove contacts
 *
 * Attribute features
 *  if the phone is off. It is not connected.
 *  if the phone is not connected there is no signal strength
 *  the attribute for battery life has valid range [0,100]. 0 is flat, 100 is full.
 *  the attribute for signal strength has a valid range [0, 5]. 0 is no signal, 5 is best signal.
 *
 * Please implement the methods provided, as some of the marking is
 * making sure that these methods work as specified.
 *
 * @author A INFO1103 tutor.
 * @date April, 2017
 *
 */
public class KasaburyMobile
{
	public static final int MAXIMUM_CONTACTS = 10;


	/* Use this to store contacts. Do not modify. */
	protected KasaburyContact[] contacts;
	private boolean phone_status;
	private boolean network_connection;
	private int batteryLife; //battery lifeshould be the same through the class
  private int signalStrength;
	private int contactNum;

  private KasaburyContact defaultOwner; //The owner contact shouldn't be in the contacts array
//the owner contact doesn't count for getNumberOfContacts()

	/* Every phone manufactured has the following attributes
	 *
	 * the phone is off
	 * the phone has battery life 25
	 * the phone is not connected
	 * the phone has signal strength 0
	 * Each of the contacts stored in the array contacts has a null value
	 *
	 * the owner first name "Kasabury"
	 * the owner last name is "Incorporated"
	 * the owner phone number is "180076237867"
	 * the owner chat message should have only one message
	 *         "Thank you for choosing Kasabury products"
	 *
	 */
	public KasaburyMobile() {
		/* given */
		this.contacts = new KasaburyContact[MAXIMUM_CONTACTS];
		this.phone_status=false; //the phone is off
		this.network_connection=false; //the phone is not connected
    this.batteryLife=25;
		this.signalStrength=0;
		this.contactNum=0;
    this.defaultOwner = new KasaburyContact("Kasabury", "Incorporated", "180076237867");
		this.defaultOwner.addChatMessage("Kasabury","Thank you for choosing Kasabury products");
		for(int i = 0; i < MAXIMUM_CONTACTS; i++){
			this.contacts[i] = null;
		}
		//https://edstem.com.au/courses/430/discussion/35362
	}

	/* returns a copy of the owner contact details
	 * return null if the phone is off
	 */
	public KasaburyContact getCopyOfOwnerContact() {
		  if(this.phone_status==false){
		      return null; // return null if the phone is off
	    }
		  return this.defaultOwner.copy();// returns a copy of the owner contact details
	}// getCopyOfOwnerContact()


	/* only works if phone is on
	 * will add the contact in the array only if there is space and does not exist
	 * The method will find an element that is null and set it to be the contact
	 */
	public boolean addContact(KasaburyContact contact) {
		if(isPhoneOn()==true){
      if(this.contactNum < MAXIMUM_CONTACTS){
				for (int i=0;i<MAXIMUM_CONTACTS;i++ ) {
            if(this.contacts[i]==contact){
							 return false;
						}
						if(this.contacts[i]==null){
							this.contacts[i]=contact;
							this.contactNum = this.contactNum+1;
							return true;
						}
				}//for loop
			}


		}
    return false;
	} //addContact(KasaburyContact contact)

	/* only works if phone is on
	 * find the object and set the array element to null
	 */
	public boolean removeContact(KasaburyContact contact) {
     if(isPhoneOn()==true){
			 for(int i=0;i<MAXIMUM_CONTACTS;i++){
					if(this.contacts[i].equals(contact)){// find the object and set the array element to null
							 this.contacts[i]= null;
							 this.contactNum=this.contactNum-1;
							 return true;
					}else{
						continue;
					}
			 }// for loop
		}
		return false;
	}//removeContact(KasaburyContact contact)

	/* only works if phone is on
	 * return the number of contacts, or -1 if phone is off
	 */
	public int getNumberOfContacts() {
		if(isPhoneOn()==true){
		  //  for(int i=0;i<MAXIMUM_CONTACTS;i++){
			//   	if(this.contacts[i]!=null){
			// 			 this.contactNum=this.contactNum+1;
			// 	  }else if(this.contacts[i]==null){
			// 			 continue;
			// 		}
		  //  }//for loop
		  return this.contactNum;
	  }
 	 return -1;
	// 	if(this.phone_status==true){
	// 		 int count=0;
	// 	   for(int i=0;i<contacts.length;i++){
	// 		  	if(this.contacts[i]!=null){
	// 					 count=count+1;
	// 			  }else if(this.contacts[i]==null){
	// 					 continue;
	// 				}
	// 	   }//for loop
	// 	  return count;
	//   }
 // 	 return -1;
	}//getNumberOfContacts()

	/* only works if phone is on
	 * returns all contacts that match firstname OR lastname
	 * if phone is off, or no results, null is returned
	 */
	public KasaburyContact[] searchContact(String name) {
    // count for the length of temporary KasaburyContact array
  if(isPhoneOn()){
		int count = 0;
		for(int i=0;i<MAXIMUM_CONTACTS;i++){
			if(contacts[i]!=null&&getNumberOfContacts()!=0){
			  if(this.contacts[i].getFirstName().equals(name) || this.contacts[i].getLastName().equals(name)){
					 count=count+1; // it impossible for a contact to have last and first name be same
			  }else{
				   continue;
			  }
			}//if(contacts[i]!=null)
		}//for loop

    if(count!=0){
		KasaburyContact[] temp=new KasaburyContact[count];
    if(this.phone_status==true){
			for(int b=0;b<count;b++){
				for(int i=0;i<this.contacts.length;i++){
					if(contacts[i]!=null&&getNumberOfContacts()!=0){
 			  	     if(this.contacts[i].getFirstName().equals(name) || this.contacts[i].getLastName().equals(name)){
 						        temp[b] = this.contacts[i];
 				       }
				  }//if(contacts[i]!=null)
 			  }//for loop
			}
			 return temp;
	  }
	}
}// if(isPhoneOn())
		return null;
	}//searchContact(String name)

	/* returns true if phone is on
	 */
	public boolean isPhoneOn() {
     if(this.phone_status==true){ //if the phone is on
			  return true;
		 }
		 return false;
	}//isPhoneOn()

	/* when phone turns on, it costs 5 battery for startup. network is initially disconnected
	 * when phone turns off it costs 0 battery, network is disconnected
	 * always return true if turning off
	 * return false if do not have enough battery level to turn on
	 * return true otherwise
	 */
	 public boolean setPhoneOn(boolean on) {
		  if(on==true){ //phone is not turn on and we set it to turn on
				if(this.batteryLife<6){ //if do not have enough battery level to turn on
				  this.phone_status = false;
					this.network_connection=false;
					this.batteryLife=this.batteryLife;
					this.signalStrength=0;
					return false;
				}else{
					this.phone_status = true;
					this.batteryLife = this.batteryLife-5;
					this.network_connection=false;
					this.signalStrength=0;
					return true;
				}
			}

      if(on==false){ //phone is on and now will be turned off
        this.phone_status = false;
				this.network_connection=false;//network is disconnected
        this.batteryLife = this.batteryLife;
				this.signalStrength = 0;
				return true;
			}
      return true;
	}//setPhoneOn(boolean on)

	/* Return the battery life leve. if the phone is off, zero is returned.
	 */
	public int getBatteryLife() {
		 if(isPhoneOn()==true){
			  return this.batteryLife;
	   }
			return 0;
	}//getBatteryLife()

	/* Changes the battery and therefore changing the battery level.
	 * The phone is switched to the off state after this operation and the battery life is updated.

	 * On success. The phone is off and new battery level adjusted and returns true

	 * If newBatteryLevel is outside manufacturer specification of [0,100], then
	 * no changes occur and returns false.
	 */
	public boolean changeBattery(int newBatteryLevel) {
		if(newBatteryLevel<0 || newBatteryLevel>100){
			 return false;
		}else{
		   this.phone_status=false;
			 this.batteryLife = newBatteryLevel;
			 return true;
		}
	}//changeBattery(int newBatteryLevel)

	/* only works if phone is on.
	 * returns true if the phone is connected to the network
	 */
	public boolean isConnectedNetwork() {
		if(isPhoneOn()==true && this.network_connection==true){
		        return true;
		}
		return false;
	}//isConnectedNetwork()

	/* only works if phone is on.
	 * when disconnecting, the signal strength becomes zero
	 */
	public void disconnectNetwork() {
		if(isPhoneOn()==true&&this.network_connection==true){
				 this.network_connection=false; //Disconnects from a network
				 this.signalStrength=0; // sets the signal strength to 0
		}
	}//disconnectNetwork()

	/* only works if phone is on.
	 * Connect to network
	 * if already connected do nothing
	 * if connecting:
	 *  1) signal strength is set to 1 if it was 0
	 *  2) signal strength will be the previous value if it is not zero
	 *  3) it will cost 2 battery life to do so
	 * returns the network connected status
	 */
	public boolean connectNetwork() {
       if(isPhoneOn()==true){
           if(isConnectedNetwork()==true){//if already connected do nothing
						    return true;
					 }
					 if(isConnectedNetwork()==false&&this.batteryLife<=2){ //if connecting
                this.signalStrength=0;
								this.network_connection=false; //the phone is not connected
						    this.batteryLife=this.batteryLife; //assume phone is not off
								return false;
					 }
					 if(isConnectedNetwork()==false&&this.batteryLife>2){ //if connecting
						 this.network_connection=true;
						 this.batteryLife = this.batteryLife-2; //cost 2 battery life to connect network
						 if(this.signalStrength==0){
								this.signalStrength=1;
						 }else{ //signal strength will be the previous value if it is not zero
								this.signalStrength=this.signalStrength; //do nothing on signalStrength
						 }
						 return true;
					 }//if(isConnectedNetwork()==false&&this.batteryLife>2)
       }// if phone is on
			 this.batteryLife=0;
			 return false; //if phone is off do nothing
	}//connectNetwork()

	/* only works if phone is on.
	 * returns a value in range [1,5] if connected to network
	 * otherwise returns 0
	 */
	public int getSignalStrength() {
      if(isPhoneOn()==true){ //if phone is on
           if(this.network_connection==true){
						  if(this.signalStrength<=5 && this.signalStrength>=0){
								 return this.signalStrength;
							}else if(this.signalStrength>5){
								 return 5;
							}else if(this.signalStrength<0){
								 return 0;
							}
					 }else if(this.network_connection==false){ //if not connected to network
						 return 0;
					 }
      }
	     return 0; //if phone is off
	}//getSignalStrength()


	/* only works if phone is on.
	 * sets the signal strength and may change the network connection status to on or off
	 * signal of 0 disconnects network
	 * signal [1,5] can connect to network if not already connected
	 * if the signal is set outside the range [0,5], nothing will occur and will return false
said it another way:
	 *If the network is connected. The signal strength can move from values 1 to5 without costing any battery life.
   *If the network is disconnected and signal strength is set to > 0. The connection occurs and costs 2 battery life.
	 */
	public boolean setSignalStrength(int x) {
     if(isPhoneOn()==true){
        if(x<0||x>5){
					return false;
				}
				if(isConnectedNetwork()==true && x==0){//signal of 0 disconnects network
					 this.signalStrength=0;
           this.network_connection=false;
					 this.batteryLife=this.batteryLife;
					 return false;
				}
				if(isConnectedNetwork()==false && x==0){//signal of 0 disconnects network
					 this.signalStrength=0;
           this.network_connection=false;
					 this.batteryLife=this.batteryLife;
					 return false;
				}
        if(isConnectedNetwork()==false && x>0){
					   this.signalStrength=x;
             this.batteryLife=this.batteryLife-2;
						 this.network_connection=true;
					   return true;
				}
        if(isConnectedNetwork()==true && x > 0){
					this.signalStrength=x;
					this.network_connection=true;
					this.batteryLife=this.batteryLife;
			    return true;
				}
		 }
		return false; // phone is off
	}//setSignalStrength(int x)

	/* each charge increases battery by 10
	 * the phone has overcharge protection and cannot exceed 100
	 * returns true if the phone was charged by 10
	 */
	public boolean chargePhone() {
     if(this.batteryLife+10 > 100){
        this.batteryLife=100;
		 }else if(this.batteryLife+10 <= 100){
			  this.batteryLife=this.batteryLife+10;
		 }
		 return true;
	}//chargePhone()

	/* Use the phone which costs k units of battery life.
	 * if the activity exceeds the battery life, the battery automatically
	 * becomes zero and the phone turns off.
	 */
	public void usePhone(int k) {
     if(this.batteryLife-k<=0){
        this.batteryLife = 0;
			  this.phone_status=false;
		 }else{
			  this.batteryLife = this.batteryLife-k;
		 }
	}//usePhone(int k)

}//Mobile Class
