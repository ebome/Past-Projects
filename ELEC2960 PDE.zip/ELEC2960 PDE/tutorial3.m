function T = tutorial3(timestart,timeend,nt,plotFlag)

% File name: tutorial3_complete
% Author: Aditya Vishwanathan and Andre Kyme
% Date: Mar 2017
%
% Description: This file provides the template within which you can
% implement the Fourier Series solution to the heat equation.
%
% Input parameters:
% - timestart - starting time in seconds (usually 0)
% - timeend   - ending time in seconds
% - nt        - number of points in time vector
% - plotFlag  - if set to 1, time animation plots will be drawn, if no
%               plots are desired set this to 0
%
% Note that you have to add in the specific values for your problem which
% have been given dummy values of single quotation marks ('').
%
% No need to run the clear commands inside a function. A function uses a
% series of dummy variables that do not alter the variables inside the
% workspace
% clear all; clc; clf;

% Spatial (x) parameters
L      = 0.12;                        % Size of the domain
rstart = 0;                        % Start of computational domain (m)
rend   = L;                        % End of computational domain (m)
nr     = 100;                      % Number of grid points in r direction
dr     = (rend - rstart)/(nr - 1);  % Spatial step size, delta r (m)
r      = rstart: dr : rend;         % Vector of grid points in r

% Temporal (t) parameters 
dt        = (timeend - timestart)/(nt-1); % Temporal step size, delta t (s)
time      = timestart: dt : timeend;      % Time vector 

% Phyiscal parameters
T1    = -41; % Temperature at r=0
T2    = 37; % Temperature at r=L
A     = 78; % Amplitude of the saw tooth wave
k     = 0.527; % Thermal conductivity (W/m-K)
rho   = 1000; % Density (kg/m^3)
sigma = 3600; % Heat capacity (J/kg-K)
c     = sqrt(k/(rho*sigma)); % Heat equation constant                 

% Fourier term parameters
nfs = 1000;      % loop 1000 times, to get a more precise solution      % Number of terms in the Fourier Series Expansion

% Calculate B coefficients using for loop
B = zeros(1,nfs);                  % Allocate the matrix (make vector of same size)   
for nf = 1:nfs;                    % For each individual term in the series
    B(nf)=(2*A)/(nf*pi);   % Find the Bn at that n
end

% % Initialise the array Bn. Instead of using a for loop, vectorise (use of
% % vectors to speed up the process)
% nFourierTerms = 1:nfs;
% B = '';

% NOTE: do not call a variable the same name as a MATLAB function. For
% example, 'sum' is an internal MATLAB function which is very useful. To
% check if you think it's a function, type in help func (e.g. help sum) in 
% the Command Window.

% Three solution loops are shown which all find the solution to the 
% equation. Each subsequent are more vectorised than the previous. To run
% any new section, comment out the old section (Ctrl + R) and uncomment 
% the new section (Ctrl + T)

%% First section: three for loops in time, space and Fourier series

for n = 1:nt   % For each time point
    
    % Find the time n
    t = time(n);
    
    % Vector of initial fourier series sum values filled with zeros. At
    % each new time step, a new vector of zeros is created for adding the
    % new series of Fourier Series
    T = zeros(1,nr); 
    
    for i = 1:nr;       % For each grid point        
        T(i) = ((T2-T1)/L)*r(i)+T1;  % r is a vctor,if we want to reference any particular index i in array, we need to say the index         % Add the steady state solution
        
        for nf = 1:nfs;              % Sum each individual term in the series
            lambda_n = (nf*pi*c)/L;     % Find lambda at that Fourier term
            T(i)    = T(i) + B(nf)*sin((nf*pi*r(i))/L)*exp(-(lambda_n^2)*t);    
                     %T(i)has been initialized so add it again 
        end
    end
    
    % Plot the solution
    if plotFlag==1
        plot(r,T); grid on;                 
        xlabel('r (m)');            % Do not forget the unit from the plot
        ylabel('T (deg)');
        title(['Time: t = ', num2str(t), ' s'])
        drawnow;                    % Animate the plot (use instead of pause)'
    end
end


%% Second section: removing the spatial grid for loop (i) ������־���Ϊ�˱���For loopǶ���������������������Ĳ���

% for n = 1:nt   % For each time point
%     
%     % Find the time n
%     t = time(n);
%     
%     % Make the steady-state solution the initial condition
%     T = ((T2-T1)*r)/L+T1;
%     
%     % Run through the Fourier Series (no need to run through the spatial
%     % grids now)
%     for nf = 1:nfs
%         lambdan = '';     % Find lambda at that Fourier term
%         T       = '';    
%     end
%     
%     % Plot the solution
%     if plotFlag==1
%       plot(r,T); grid on;                 
%       xlabel('r (m)');            % Do not forget the unit from the plot
%       ylabel('T (deg)');
%       title(['Time: t = ', num2str(t), ' s'])
%       drawnow;                    % Animate the plot (use instead of pause)
%    end
% end


%% Third section: removing spatial grid (i) and time (n) using 2D matrices
% which contain both spatial and temporal information. MATLAB functions
% sin() and exp() can take in matrices. 

% [R, T] = meshgrid(r, time);  % Make the matrices of space (R) and time (T)
% T      = '';    % Make the steady-state (function of X only)
% for nf = 1:nfs
%     lambdan = '';
%     T = ''; % Add each Fourier
% end
% 
% % Plot the time in a separate loop
% for i = 1:nt
%     t = time(i);
%     
%     % Plot the solution
%     if plotFlag==1
%       plot(r,T); grid on;                 
%       xlabel('r (m)');            % Do not forget the unit from the plot
%       ylabel('T (deg)');
%       title(['Time: t = ', num2str(t), ' s'])
%       drawnow;                    % Animate the plot (use instead of pause)
%    end
% end
