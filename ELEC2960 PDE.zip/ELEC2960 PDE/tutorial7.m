function distance = tutorial7(dt,nt,plotFlag)

% File name: tutorial7
% Author: Andre Kyme
% Date: April 2017
%
% Description: This file provides the template within which you can
% implement the analytical solution to the D&G perfume diffusion problem using the Fourier
% intergral.
%
% Input parameters:
% - dt       - timestep size
% - nt       - number of grid points in t
% - plotFlag - 1 for time animation plot, 0 for no plot 
%
% Output parameters:
% The function should return "distance", equal to the total length of the alleyway impacted by
% the D&G marketing campaign.


% Spatial (x) parameters
% NB. We want the D&G shop to be at x=0 and to create a grid that extends 200 m to the left and to the right, in 1 m increments.
L      = 400;                       % size of the domain
nx     = 401;                        % number of grid points
xstart = -200;                        % start of computational domain (m)
xend   = 200;                        % end of computational domain (m)
dx     = (xend - xstart)/(nx - 1);  % spatial step size, delta x (m)
x      = xstart: dx : xend;         % vector of grid points

% Physical parameters
c = sqrt(5e-3);                             % constant c in the governing equation
smell_thold = 5e-3;                   % mass fraction threshold for smelling the perfume

% Initialise distance
distance = 0;                       % distance of perfume diffusion

%% Main solution loop

for n=1:nt
    
    time = n*dt;                        % current time for outputted solution

    % Analytical solution
    y=zeros(1,nx);                  % re-initialise the solution array
    for i=1:nx;                     % loop through grid points
       y(i) = 0.5*(erf( (1-x(i))/(2*c* sqrt(time) ) )+erf( (1+x(i))/(2*c* sqrt(time) )) );
    end

    % Plot analytical vs numerical solution
    if plotFlag==1
        plot(x,y,'r+');
        axis([-200 200 0 0.1]);
        xlabel('x (m)');
        ylabel('Mass fraction y');
        title('Mass Fraction of Perfume');
        pause(0.01);
    end

    %% Compute total distance along alleyway % this part will tell the distance between the maximal smell and the threshold smell
    % (NB. you can comment out this section to test if your code above. Once it looks ok, complete this part and run the Ptest)
  
    ix = find(y > smell_thold);             % to better understand what this line is doing, type >> help find % Find() gives only one index of the desired thing
    if isempty(ix) == 0                     % to better understand what this line is doing, type >> help isempty
        cur_distance = 2*abs(x(ix(1)) ); %max(ix)-min(ix); But in this question the increment is 1m so we can use this, if the increment is not 1m then we can't use max-min        % compute the total length of alleyway in which perfume can be detected
        if cur_distance > distance
            distance = cur_distance;        % update the max distance if necessary
        end
    end

end