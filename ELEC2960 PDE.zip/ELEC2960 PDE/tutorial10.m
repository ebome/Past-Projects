function Tnp1 = tutorial10(nx,dt,nt,plotFlag)

% File name: tutorial10
%
% Description: This file is a template for the BTCS numerical solution to the heat
% equation. The analytical solution from Week 3 is included for comparison.
%
% Input parameters:
% - nx       - number of grid points in x
% - dt       - timestep size
% - nt       - number of time steps
% - plotFlag - 1 for time animation plots, 0 for no plots 

% Spatial (x) parameters
L      = 0.12;                              % Size of the domain
xstart = 0;                                 % Start of computational domain (m)
xend   = xstart + L;                        % End of computational domain (m)
dx     = (xend - xstart)/(nx - 1);          % Grid size in x (m)
x      = xstart: dx : xend;                 % Vector of grid points

% Phyiscal parameters
T1    = -41;                                % Temperature at x=0
T2    = 37;                                 % Temperature at x=L
An    = T2-T1;                              % Amplitude of the saw tooth wave
k     = 0.527;                              % Thermal conductivity (W/m-K)
rho   = 1000;                               % Density (kg/m^3)
gamma = 3600;                               % Heat capacity (J/kg-K)
D     = k/rho/gamma;                        % Thermal diffusivity 

% Fourier series parameters
nfs           = 1000;                       % Number of fourier terms
nFourierTerms = 1:nfs;
B             = 2*An./( nFourierTerms*pi ); % B coefficients of series

% Initialise solution arrays: Tn and Tnp1 for numerical and TExact for analytical
Tn     = zeros(nx,1);                                % Current value of temperature at time n (this should be a column vector not a row vector)
TExact = zeros(1,nx);                                % Exact fourier series solution for temperature

% Specify the initial conditions
for i=2:nx-1
    Tn(i) = T2 ;
end

% Enforce the boundary conditions - these never change in the simulation
Tn(1)      = T1;
Tn(nx)     = T2;

% Construct the A matrix
r = -(D*dt)/(dx^2) ;
nOnes = ones(nx,1);
lower_diag = diag(r*nOnes(1:nx-1),-1);
upper_diag = diag(r*nOnes(1:nx-1),1);
mid_diag   = diag((1-2*r)*nOnes, 0);
A = lower_diag + mid_diag + upper_diag;

% Enforce the boundary conditions
A(1,1) = 1;
A(1,2) = 0; %����A��1,2������Ϊ����create Aʱ�õ�diag������A��1,1����A��1,2����������ֵ
A(nx,nx-1) = 0;
A(nx,nx) = 1;


%% Main solution loop

for n=1:nt
    
    t=n*dt;                            % Current time for outputted solution
    
    % Analytical solution (this is from Week 3)
    for i=1:nx;                        % Loop through grid points
        TExact(i)=T1+(T2-T1)*x(i)/L;   % Add the steady state solution
        for j=1:nfs;                   % Sum each individual term in the series
            lambdan  = sqrt(D)*j*pi/L;
            TExact(i)= TExact(i)+B(j)*sin(j*pi*x(i)/L)*exp(-lambdan^2*t);   % Analytical solution
        end
    end
 
 
    % Numerical solution
    Tnp1 = A\Tn;
 
    
    % Plot analytical vs numerical solution
    if plotFlag==1
        plot(x,Tnp1,'r+',x,TExact,'ko')  
        xlabel('x (m)')
        ylabel('T (degC)')
        title('Analytical vs Numerical Solution')
        pause(0.03);
    end
    
    % Copy solution to initial conditions for next iteration.������Ľ������µ�IC��
    Tn = Tnp1;
end

end
