% tutorial8.m
% This template script allows you to read in the ECG signal. You should add
% in code to process the data so that a sensible diagnosis can be made.


clear all
clc

% Note: The ECG data files have a single column of data points, equally
% spaced in time

% Read in the data file
ecg.name = 'Gp1';
ecg.ext = '.csv';

filename            = [ecg.name ecg.ext];                                               % Filename
delimiterIn         = ',';                                              % Entries are comma delimited
headerlinesIn       = 0;                                                % No header
ecgData             = importdata(filename,delimiterIn,headerlinesIn);   % Read the file into an array called ecgData

%Plot the ECG data in the temporal domain
figure(1);
FigHandle = figure(1);
set(FigHandle, 'Position', [100, 100, 900, 600]);
subplot(3,1,1);
xaxis = 0:(1/360):20;                        % measure the ECG for 20s
plot(xaxis,ecgData(1,:),'k')                 % Plot the  signal, delta_t = 1/360
% axis([0 25 -40 40]);
xlabel('t(s)')
ylabel('Magnitude (micro V)')
title('EEG Signal')



% Set up for FFT
T = 1./360;                                                   % Time interval between each sample (s) (hint: what data are recorded in column 1 of your files?)
Fs = 1./T;                                                % Sampling frequency
L = 7201;                                                   % Number of samples (hint: look at your variables in the workspace - how many entries for each of your signals?)
t = (0:L-1)*T;                                            % Time vector
NFFT = 2^nextpow2(L);                                     % Next power of 2 from length of y, If it's not a power of 2, it cannot work efficiently
% we could see the "fft" function in documentation of Matlab


%Calculate the FFT of the ecg data
Y_data = fft(ecgData(1,:),NFFT);                                                  % Hint - see the example in FFT.m
% Ys = fft(ecgTest(1,:),NFFT);

%Construct the points along the frequency axis
f = Fs/2*linspace(0,1,NFFT/2+1);                                                   % Hint - see the example in FFT.m


% Plot single-sided amplitude spectrum
subplot(3,1,2);
plot(f,2*abs(Y_data(1:NFFT/2+1)),'k');
title('Amplitude Spectrum of ECG Control')
xlabel('Frequency(Hz)')
ylabel('Amplitude')

% Create filter
cutoff = 2*(30/Fs);
[b,a] = butter(10,cutoff, 'low');
data_filt = filtfilt(b,a,ecgData );

% Filter
subplot(3,1,3);
%axis ([0 20 20 0]);
plot(xaxis,data_filt,'k');
title('The filtered ECG')
xlabel('time(s)')
ylabel('Magnitude (micro V)')




% Plot filtered data