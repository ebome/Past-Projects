function Css = tutorial12(c0,c1,c2,c3)

% File name: tutorial12
%
% Description: This file is a template for the analytical solution to the
% Laplace equation.
%
% Input parameters:
% c0       - concentration at the top boundary
% c1       - concentration at the right boundary
% c2       - concentration at the bottom boundary
% c3       - concentration at the left boundary
%
%               C0
%          _____________
%         |             |
%         |             |
%     C3  |             |  C1
%         |             |
%         |_____________|
%
%               C2
%

% Spatial parameters
a = 100e-6;                                     % Length of x dimension
b = 50e-6;                                     % Length of y dimension
nx =101;     % We can't use a/(1e-6)+1 since it gives a float point;          % Number of grid points in x
ny =51;      % We can't use b/(1e-6)+1 since it gives a float point;          % Number of grid points in y
x = 0:1e-6:a;                                     % Vector of grid points in x
y = 0:1e-6:b;                                     % Vector of grid points in y
nfs =100 ;                                   % Number of Fourier terms

% Initialise solution array
Css = zeros(nx,ny);

% Analytical solution
for i=1:nx
   for j=1:ny
      for m = 1: nfs   %m is looping through Fourier modes
         % Fill in the analytical solution here
         top_side = (2*c0/pi)*[(1-cos(m*pi))/(m*sinh(m*pi*b/a))]*[sinh(m*pi*y(j)/a)]*[sin(m*pi*x(i)/a)];
         right_side = (2*c1/pi)*[(1-cos(m*pi))/(m*sinh(m*pi*a/b))]*[sinh(m*pi*x(i)/b)]*[sin(m*pi*y(j)/b)];
         bottom_side = (-2*c2/pi)*[(1-cos(m*pi))/(m*sinh(m*pi*b/a))]*[sinh(m*pi*(y(j)-b)/a)]*[sin(m*pi*x(i)/a)];
         left_side = (-2*c3/pi)*[(1-cos(m*pi))/(m*sinh(m*pi*a/b))]*[sinh(m*pi*(x(i)-a)/b)]*[sin(m*pi*y(j)/b)];    
         Css(i,j) = Css(i,j)+top_side+right_side+bottom_side+left_side;   
      end
   end
end

% Display the steady-state result
pcolor(x,y,Css'),shading interp,title('Concentration (Steady State)'),xlabel('x'),ylabel('y'),colorbar;

end