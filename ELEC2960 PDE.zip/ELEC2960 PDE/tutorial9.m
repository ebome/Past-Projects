function p = tutorial9(dt, nt, plotFlag)

% Set up key parameters
vd = 0.005 ;                % Vessel diameter
A = pi* (vd/2)^2;                 % Vessel cross-sectional area
rho = 1000;               % Density of blood
C =1e-8;                 % Vessel compliance
c = sqrt( A/(rho*C));                 % Wave speed

% Set up grids
L = 0.1;                % Set the problem length
nx = 1001;              % Number of grid points
x = linspace(0,L,nx);                 % Grid in x
tstart = 0;             % Start time
tend = dt*nt;              % End time
t  = tstart:dt:tend;                % Grid in time


%% Analytical representation

p = zeros(1,nx);                 % Initialise p

for n=1:length(t)

   % Note: Because the computational expense of computing the analytical
   % solution for this problem is greater than for earlier problems we've
   % covered, if we use 2 loops (one through time and one through x) it
   % will take too long to compute and animate. Therefore, we need to
   % 'vectorise' our code slightly to remove the loop through x. This means
   % that instead of computing the result for each element x(i) as you've
   % done previously, we will compute the result for all elements of x at
   % once. To see what we mean, try typing the following at the command line:
   % >> a = [1 5 -6 3 18 4 4 2 0 20];
   % >> b = a./5
   % What does Matlab output?


   % Vectorised computation of p(x,t) which avoids looping through x
   p = sin((2*pi*(t(n)-x./c))/0.004).*exp((t(n)-x./c)*(-250)).*heaviside(t(n)-x./c);                                         % Analytical solution
% adding dot when array*array, no need to add dot when array*number, t(n)
% in this case is a number but not an array.
   
   % Animate
   if plotFlag
      plot(x,p); grid on;                          % Plot the data, show an x-y grid
      axis([0 0.1 -1 1]);                          % Set the scale of the x and y axes
      xlabel('x (m)');
      ylabel('p (Pa)');
      title(['Time: t = ', num2str(t(n)), ' s'])   % Display the current time
      drawnow;
   end

end

end