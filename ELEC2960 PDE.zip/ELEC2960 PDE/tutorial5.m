function y = tutorial5(tfinal,nfs,plotFlag)

% File name: tutorial5
% Author: Andre Kyme and Aditya Vishwanathan
% Date: Mar 2017
%
% Description: This file provides the template within which you can
% implement the analytical solution to the wave equation (guitar string)
% Input parameters:
% - tfinal   - ending time (s)
% - nfs      - number of Fourier terms
% - plotFlag - 1 for time animation plots, 0 for no plots 
%
% Output parameter:
% - y        - guitar string deflection (m)

% Spatial (x) parameters
L      = 0.65;                      % Size of the Domain
nx     = 101;                       % Number of grid points
xstart = 0;                         % Start of computational domain (m)
xend   = xstart + L;                % End of computational domain (m)
dx     = (xend - xstart)/(nx - 1);  % Spatial step size, delta x (m)
x      = xstart: dx : xend;         % Vector of grid points from p to q

% Temporal (t) parameters
tstart = 0;                         % Starting time (s)
dt     = 0.00001;                   % Time step (s)
time   = tstart : dt : tfinal;   % Time vector 

% Phyiscal parameters
T      = 71;                        % Tension in string (N)
rho    = 0.401e-3;                  % Mass per unit length (kg/m)
c      = sqrt(T/rho);               % PDE constant 
k      = 0.005;                     % Initial displacement (m) 

%Initialise the array Bn for the analytical solution.
%Faster to compute this first as it never changes
B=zeros(1,nfs);
for n=1:nfs; %sum each individual term in the series
    B(n)=(8*k/(n^2*pi^2))*sin(n*pi/2);
end

%% Main solution loop

for t=1:length(time)

    y=zeros(1,nx); % Initialise the solution array for the analytical solution

    for i=1:nx;         % For each grid point

        for n=1:nfs;    % Sum each individual term in the series
            lambdan=c*n*pi/L;
            y(i)=y(i)+B(n)*cos(lambdan*time(t))*sin(n*pi*x(i)/L);
        end

    end

    if (plotFlag == 1)
        plot(x,y,'ko')            % plot of numerical and exact solutions
        axis([xstart xend -k k])  % scale the axes (plot automatically adjusts after this)
        xlabel('x(m)')
        ylabel('Deflection y(m)')
        title('Solution to ytt=c^2yxx, o analytical')
        pause(0.01)               % pause in seconds between plots
    end
         
end