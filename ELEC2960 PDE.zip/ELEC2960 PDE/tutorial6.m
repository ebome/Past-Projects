function meanError = tutorial6(nx,dt,nt,plotFlag)

% File name: tutorial6_complete
% Author: Andre Kyme and Aditya Vishwanathan 
% Date: Mar 2017
%
% Description: This file provides the template within which you can
% implement the analytical vs numerical solution to the wave equation
%
% Input parameters:
% - nx       - number of grid points in x
% - dt       - timestep size
% - nt       - number of grid points in t
% - plotFlag - 1 for time animation plots, 0 for no plots 
%
% Note that you have to add in the specific values for your problem

% Spatial (x) parameters
L      = 0.035;                     % size of the domain
xstart = 0;                         % start of computational domain (m)
xend   = xstart + L;                % end of computational domain (m)
dx     = (xend - xstart)/(nx - 1);  % spatial step size, delta x (m)
x      = xstart: dx : xend;         % vector of grid points from p to q

% Physical parameters.
l = 0.001;                          % height of fluid chamber (m)
K = 1.;                             % membrane stiffness (N/m)
rho = 10.^3;                        % fluid density (kg/m^3)
c = sqrt(l*K/(2*rho));              % constant c in the governing equation
hx0 = 0;                            % h(x=0,t)
hxL = 0;                            % h(x=L,t)
A = 8.e-9;                          % coefficient of the first mode in the initial condition (m)
B = 5.e-9;                          % coefficient of the second mode in the initial condition (m)
C = 1.e-9;                          % coefficient of the third mode in the initial condition (m)
nfs = 3;                            % number of terms in the Fourier Series Expansion for analytical (since we only have 3 modes initially, the full solution will only have 3 modes)

% Initialise the solution arrays for the numerical solution: hn (h^n), hnp1 (h^(n+1)), hnm1 (h^(n-1)) as vectors of zeros with length nx
hn     = zeros(1,nx);    % current value of h (deflection) at time n
hnp1   = zeros(1,nx);    % next value of h at time n+1
hnm1   = zeros(1,nx);    % previous value at time n-1

% Initialise the solution arrays for the analytical solution: hExact as a vector of zeros with length nx 
hExact = zeros(1,nx);    % exact fourier series solution for h

% Bn for the analytical solution
Bn = [A, B, C];

% Compute the lambdan for the analytical solution
lambda2 = c*2*pi/L;
lambda5 = c*5*pi/L;
lambda19 = c*19*pi/L;

% Specify the initial conditions for the numerical solution
for i=2:nx-1
    hn(i) = Bn(1)*sin(2*pi*x(i)/L) + Bn(2)*sin(5*pi*x(i)/L) + Bn(3)*sin(19*pi*x(i)/L);    % initial conditions
end

% Enforce the boundary conditions - these will never change in the
% simulation
hn(1)      = hx0;
hn(nx)     = hxL;
hnp1(1)    = hx0;
hnp1(nx)   = hxL;

% Set h^(n-1) to h^n to get things started
hnm1 = hn;


%% Main solution loop

for n=1:nt

    t=n*dt;                      % current time for outputted solution

    % Analytical solution (same as Week 5)
    hExact=zeros(1,nx);          % re-initialise the solution array
    for i=1:nx                 % loop through grid points
       hExact(i)= hExact(i)+Bn(1)*cos(lambda2*t)*sin(2*pi*x(i)/L)+Bn(2)*cos(lambda5*t)*sin(5*pi*x(i)/L)+Bn(3)*cos(lambda19*t)*sin(19*pi*x(i)/L);
    end

    % Numerical solution - note that we only need to solve for i=2, nx-1 as
    % the first and last points are fixed by the boundary condition
    sigma=((dt^2)*(c^2))/(dx^2);
    for i=2:nx-1
        hnp1(i) = 2*hn(i)-hnm1(i)+sigma*(hn(i+1)-2*hn(i)+hn(i-1));
    end

    % Plot analytical vs numerical solution
    if plotFlag==1
        plot(x,hnp1,'r+',x,hExact,'ko');
        axis([xstart xend -(A+B+C) (A+B+C)]);
        xlabel('x (m)');
        ylabel('Deflection h (m)');
        title('Analytical vs Numerical Solution');
        %legend('numerical','analytical');
        pause(0.01);
    end

    % For the next iteration:
    % - Copy current to previous
    % - Copy new solution to initial conditions
    % Note only copy the computed values otherwise you may overwrite the boundary conditions!
    hnm1(2:nx-1) = hn(2:nx-1);
    hn(2:nx-1) = hnp1(2:nx-1);

end
meanError=mean(abs((hn(2:nx-1)-hExact(2:nx-1))*100./hExact(2:nx-1)));

