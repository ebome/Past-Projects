function err = tutorial2(nPoints)
%% Trapezoidal approximation of integral 4/(1 + x^2) from x = 0 to x = 1
% inputs:   - nPoints    number of points in domain
% outputs:  - err        percentage error (absolute value)

% Initialize variables
L=1;
x = linspace(0,L,nPoints); % rather than use x = dx:dx:x_end, we define delta(x) using linspace
y = zeros(size(x)); % We ask a array of y in the same size of created x, at initialize step, we ask y is a zero array; later we will ask y to get the values we want

% get the 2 ends
y(1)=2/(1+0);
y(nPoints)=2/(1+x(nPoints)^2);

% Update
for n = 2: nPoints-1
    y(n) = 4/(1+x(n)^2);  
end

numericalana = (L/(nPoints-1))*(sum(y));  

err = 100*abs(pi-numericalana)/pi

return