function meanError = tutorial4(nr,dt,nt,plotFlag)

% File name: tutorial4
% Author: Aditya Vishwanathan and Andre Kyme 
% Date: Mar 2017
%
% Description: This file provides the template within which you can
% implement the analytical vs numerical solution to the heat equation
%
% Input parameters:
% - nr       - number of grid points in r
% - dt       - timestep size
% - nt       - number of grid points in t
% - plotFlag - 1 for time animation plots, 0 for no plots 
%
% Note that you have to add in the specific values for your problem

% Spatial (x) parameters
L      = 0.12;                      % Size of the domain
rstart = 0;                         % Start of computational domain (m)
rend   = rstart + L;                % End of computational domain (m)
dr     = (rend - rstart)/(nr - 1);  % Spatial step size, delta r (m)
r      = rstart: dr : rend;         % Vector of grid points from p to q

% Phyiscal parameters
T1    = -41;                % Temperature at r=0
T2    = 37;                 % Temperature at r=L
A     = T2-T1;              % Amplitude of the saw tooth wave
k     = 0.527;              % Thermal conductivity (W/m-K)
rho   = 1000;               % Density (kg/m^3)
gamma = 3600;               % Heat capacity (J/kg-K)
c     = sqrt(k/rho/gamma);  % Heat equation constant, to prevent confusion, we use gamma rather than sigma compare to tutorial3 

% Initialise the solution arrays - Tn (T^n) and Tnp1 (T^(n+1)) and exact
% solution TExact
Tn     = zeros(1,nr);    % Current value of temperature at time n
Tnp1   = zeros(1,nr);    % Next value of temperature at time n+1
TExact = zeros(1,nr);    % Exact fourier series solution for temperature

% Specify the initial conditions
for i=2:nr-1
    Tn(i) = T2 ;    % initial conditions
end

% Enforce the boundary conditions - These will never change in the
% simulation
Tn(1)      = T1; %��Tnʱ����ϣ�����һ�����ڿռ�r��array��ȡ���еĵ�1���ĵ�
Tn(nr)     = T2; 
Tnp1(1)    = T1; %��Tn+1ʱ����ϣ�����һ�����ڿռ�r��array��ȡ���еĵ�1���ĵ�
Tnp1(nr)   = T2; %��Tn+1ʱ����ϣ�����һ�����ڿռ�r��array��ȡ�������һ����

% Fourier term parameters
nfs = 1000;      % loop 1000 times, to get a more precise solution ;              % Number of terms in the Fourier Series Expansion

% Calculate B coefficients using for loop
B = zeros(1,nfs);                  % Allocate the matrix (make vector of same size)   
for nf = 1:nfs;                    % For each individual term in the series
    B(nf) = (2*A)/(nf*pi);   % Find the Bn at that n
end

%% Main solution loop

for n = 1:nt
    
    t = n*dt;               % current time for outputted solution
    
    % Analytical solution (same as Week 3)
    for i=1:nr;              % for each grid point
        TExact(i)  = ((T2-T1)/L)*r(i)+T1;  % r is a vctor,if we want to reference any particular index i in array, we need to say the index
        for j=1:nfs;         %sum each individual term in the series
            lambdan  = (j*pi*c)/L;     % Find lambda at that Fourier term
            TExact(i)= TExact(i) + B(j)*sin((j*pi*r(i))/L)*exp(-(lambdan^2)*t);    
                     % TExact(i) has been initialized so add it again ;
        end
    end
    
    % Numerical solution - note that we only need to solve for i=2,nr-1 as
    % the first and last points are fixed by the boundary condition
    sigma = ((c^2)*dt)/(dr^2);
    for i=2:nr-1   % we loop through r this time
        Tnp1(i) = Tn(i)+sigma*(Tn(i+1)-2*Tn(i)+Tn(i-1)) ;
    end
    
    % Plot analytical vs numerical solution
    if plotFlag==1
        plot(r,Tnp1,'r+',r,TExact,'ko')  
        xlabel('r (m)')
        ylabel('T (degC)')
        title('Analytical vs Numerical Solution')
        h=legend('numerical','analytical');
        set(h,'location','southeast');
        pause(0.01);
    end
    
    % Copy solution to initial conditions for next iteration. Note only
    % copy the computed values otherwise you may overwrite the boundary
    % conditions!  ��һ�����˼���Լ����ıʼ�
    Tn = Tnp1 ;  
    
end
meanError = mean(abs((Tn-TExact)*100./TExact)) ;

