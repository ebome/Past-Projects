
function u = tutorial11(omega,ne)
% File name: 1DBrainBar
% Author: Lewis Collins, using Ben T code
% Description:  function m-file to solve the problem:
% d/dx(EA u_x)+q(x)=0,
% where u is displacement and q the distributed force term, using the FE
% method with ne elements.
% For this case q=const,however option of q(x) is maintained.
%
%
% Note:
% This problem has an analytical solution, given in the Week 11 Tut Sheet.
%
%

% First set the initial parameters.
L=0.093;                           %Size of the Domain
rstart=0;                           % start of computational domain (m)
rend=rstart+L;                         % end of computational domain (m)
E=2e6;                       % Elastic modulus (Pa)
A=pi*(L/2)^2;                     % Cross-sectional area (m^2)
rho=1;                        % density (kg/m^3)
% ne=10;                          % number of elements 
% omega=100;              %rotation rate (rad/sec)

%Now start making the grid in x
dl=(rend-rstart)/ne;                % element size l, we donnot use dl=(rend-rstart)/(ne-1)

r = zeros(1,ne);      % initialize the array
r = rstart+dl:dl:rend;                 % vector of node points from rstart to rend
% rstart+dl: WE DONNOT calculate U0 so we skip rstart

%Form the global stiffness matrix
nOnes = ones(ne,1);
Matrix =diag(2*nOnes,0)+diag((-1)*nOnes(1:ne-1),-1)+diag((-1)*nOnes(1:ne-1),1);
Matrix=Matrix*E*A/dl;

% Fix coefficients of boundary nodes
Matrix(end,end) = 1*(E*A/dl);

% disp(Matrix)

%Make the global displacement and global load vector
u=zeros(ne,1);             %Global displacement vector
uex=zeros(ne,1);             %Exact solution for Global displacement vector
Q=zeros(ne,1);             %Global load vector

% specify the components of the global load vector
    qtemp=rho*A*15*omega^2;
for i=1:ne
    Q(i)=qtemp*dl;
end

% specify the final term in the global load vector
Q(end)=qtemp*dl/2;  % over writing it to make sure the last elemeny


%
% Begin the solution
%

%Matrix Solve
u=Matrix\Q;

for i=1:ne
uex(i)= ((Q(i)*L^2)/(E*A))*(r(i)/L-0.5*(r(i)/L)^2);      %Analytical
%uex(i)= (qtemp*L^2)/(E*A))*(r(i)/L-0.5*(r(i)/L)^2);  is correct as well.
%Since qtemp will increse each time as r is incresing(the force applied on brain will elongate it)
end
    
    plot(r,u,'r+',r,uex,'ko')  % plot (omitting ghost values) of numerical and exact solutions
    xlabel('r')
    ylabel('Displacement (m)')
    title('comparison of displacement of brain tissue, + numerical (FEA), o analytical')
    

FinalError=abs(u((ne)/2)-uex((ne)/2))/uex((ne)/2)*100;

